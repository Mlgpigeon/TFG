from enum import Enum


class TargetEnum(Enum):
    N2074= '2074'
    N2065 = '2065'