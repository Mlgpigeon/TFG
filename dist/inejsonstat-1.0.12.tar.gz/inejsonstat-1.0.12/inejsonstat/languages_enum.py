from enum import Enum

class LanguageEnum(Enum):
    ES = 'ES'
    EN = 'EN'